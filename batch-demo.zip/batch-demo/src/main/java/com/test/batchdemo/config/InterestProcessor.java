package com.test.batchdemo.config;

import java.math.BigDecimal;

import org.springframework.batch.item.ItemProcessor;

public class InterestProcessor<T1, T2> implements ItemProcessor<Principle, Principle> {

	@Override
	public Principle process(Principle pri) throws Exception {
		pri.setCalcAmount( pri.getRateOfInterest().multiply( pri.getDuration()).multiply(pri.getPrinciple()).divide(BigDecimal.valueOf(100)));
		return pri;
	}

}
