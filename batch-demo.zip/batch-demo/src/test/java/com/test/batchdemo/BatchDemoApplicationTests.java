package com.test.batchdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
