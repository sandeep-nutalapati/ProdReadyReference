package com.test.batchdemo.config;

import java.math.BigDecimal;

public class Principle {
	
	BigDecimal principle;
	
	BigDecimal rateOfInterest;
	
	BigDecimal duration;
	
	BigDecimal calcAmount;

	public BigDecimal getCalcAmount() {
		return calcAmount;
	}

	public void setCalcAmount(BigDecimal calcAmount) {
		this.calcAmount = calcAmount;
	}

	public BigDecimal getPrinciple() {
		return principle;
	}

	public void setPrinciple(BigDecimal principle) {
		this.principle = principle;
	}

	public BigDecimal getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(BigDecimal rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public BigDecimal getDuration() {
		return duration;
	}

	public void setDuration(BigDecimal duration) {
		this.duration = duration;
	}
	
}
