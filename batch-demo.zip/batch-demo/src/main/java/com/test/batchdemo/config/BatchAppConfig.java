package com.test.batchdemo.config;

import java.net.MalformedURLException;

import javax.annotation.Resource;
import javax.xml.bind.Marshaller;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.xml.StaxEventItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.expression.ParseException;

@Configuration
public class BatchAppConfig {

	  @Autowired
	    private JobBuilderFactory jobs;
	 
	    @Autowired
	    private StepBuilderFactory steps;
	 
	    @Value("input/input.csv")
	    private Resource inputCsv;
	 
	    @Value("file:xml/output.csv")
	    private Resource outputXml;
	 
	    @Bean
	    public ItemReader<Principle> itemReader()
	      throws UnexpectedInputException, ParseException {
	        FlatFileItemReader<Principle> reader = new FlatFileItemReader<Principle>();
	        DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
	        String[] tokens = { "principle", "rateOfInterest", "duration" };
	        tokenizer.setNames(tokens);
//	        reader.setResource(inputCsv);
	        DefaultLineMapper<Principle> lineMapper = 
	          new DefaultLineMapper<Principle>();
	        lineMapper.setLineTokenizer(tokenizer);
//	        lineMapper.setFieldSetMapper(new RecordFieldSetMapper());
	        reader.setLineMapper(lineMapper);
	        return reader;
	    }
	 
	    @Bean
	    public ItemProcessor<Principle, Principle> itemProcessor() {
	        return new InterestProcessor<Principle, Principle>();
	    }
	 
	    @Bean
	    public ItemWriter<Principle> itemWriter(Marshaller marshaller)
	      throws MalformedURLException {
	        StaxEventItemWriter<Principle> itemWriter = 
	          new StaxEventItemWriter<Principle>();
//	        itemWriter.setMarshaller(marshaller);
	        itemWriter.setRootTagName("transactionRecord");
	        //write to the file
//	        itemWriter.setResource(outputXml);
	        return itemWriter;
	    }
	 
	 
	    @Bean
	    protected Step step1(ItemReader<Principle> reader,
	      ItemProcessor<Principle, Principle> processor,
	      ItemWriter<Principle> writer) {
	        return steps.get("step1").<Principle, Principle> chunk(10)
	          .reader(reader).processor(processor).writer(writer).build();
	    }
	 
	    @Bean(name = "firstBatchJob")
	    public Job job(@Qualifier("step1") Step step1) {
	        return jobs.get("firstBatchJob").start(step1).build();
	    }
	
	
}
